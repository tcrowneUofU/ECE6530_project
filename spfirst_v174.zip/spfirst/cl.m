clear all
close all force
clc