%
% This file has Revision info for the 'PhasorRaces' demo
%
%---------------------------------------------------------------------------
% PhasorRaces (phrace) version 1.16 (30-Mar-2016): 2016a update
%---------------------------------------------------------------------------
% PhasorRaces (phrace) version 1.14 (06-Apr-2015): 2014b update
%---------------------------------------------------------------------------
% PhasorRaces (phrace) version 1.1 (Rajbabu, 03-Aug-2002)
%---------------------------------------------------------------------------
% Major changes in this version were, a new layout for the tool. Functionality 
% for multiple user levels and minor bug fixes.
%
%----------------------------------------------------------------------------
% PhasorRaces (phrace) version 1.01 (Dr. James H. McClellan, 20-Jan-2001)
%----------------------------------------------------------------------------
%   The concept and original code for this program was developed by Dr. James
%   H. McClellan.
%
%----------------------------------------------------------------------------
%
% If you have any bug reports or questions, you can send email to
%
%   Professor James McClellan (james.mcclellan@ece.gatech.edu)
%
%    or
%
%   Rajbabu (rajbabu@ece.gatech.edu)
%
