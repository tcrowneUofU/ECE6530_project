function a = pickone(list)
a = list( round((length(list)-1)*rand)+1 );

