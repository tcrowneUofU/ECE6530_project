%----------------------------------------------------------------------------
%Using the Specgramdemo Graphical User Interface
%----------------------------------------------------------------------------
%
%----------------------------------------------------------------------------
%Overview
%----------------------------------------------------------------------------
%
%
%----------------------------------------------------------------------------
%Theory
%----------------------------------------------------------------------------
%
%
%----------------------------------------------------------------------------
%Specgramdemo Controls
%----------------------------------------------------------------------------
%Changing the Input Signal:
%
%

%
%Changing the Line Width:
%
%   By clicking on the Set Line Width menu, the user can change the widths of 
%   all the graph lines.  This can be useful when using this program in a 
%   class lecture to make sure the lines are visible from the back of a 
%   lecture room.
